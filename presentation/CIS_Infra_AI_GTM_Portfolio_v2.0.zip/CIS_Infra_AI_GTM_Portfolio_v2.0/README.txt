CIS Infra Azure AI GTM portfolio, version 2.0, 11 Oct 2026. Working proposal for internal leadership review.

1_Presentations: five editable PPTX decks. Each deck has a 10-slide executive section and a linked technical and commercial appendix.
2_PDF_Previews: LibreOffice-rendered previews. Rendering differs slightly from PowerPoint.
3_Architecture_Sources: editable PowerPoint shapes, connectors and labels for every new or rebuilt diagram, with official Azure SVG icons.
4_Registers: audit closure report, source register (Microsoft sources, verified prices, architecture references, icon hashes) and decision register.
5_Icons_SVG: the unmodified official Azure icons used in the decks.

Font: Arial substituted for Gellix, which was not available.
Not checked in desktop PowerPoint. Review was done on rendered PDFs, and OOXML validation passed.
Decks 04 and 05 were built new because their baseline files were not supplied.
No figure is an approved Cognizant rate, quote, staffing commitment or customer evidence.
